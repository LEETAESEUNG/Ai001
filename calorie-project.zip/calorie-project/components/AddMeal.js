import { View, Text, Button, StyleSheet, TextInput } from 'react-native'
import {useState} from 'react'

const AddMeal = ({ navigation, route }) => {
  const [food, setFood] = useState('');
  const [calories, setCalories] = useState(0);

  const handleAddMeal = () => {
    if (food && calories > 0) {
      const newMeal = { food, calories };
      const { addMeal } = route.params; // addMeal을 여기서 가져옴 -> Home으로 보내야함함
      addMeal(newMeal); // AddMeal에서 전달된 함수를 호출하여 식사를 추가합니다.
      setFood('');
      setCalories(0);
      navigation.goBack(); // 식사를 추가한 후 홈 화면으로 돌아갑니다.
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>식사 추가</Text>
      <TextInput
        style={styles.input}
        placeholder="음식 이름"
        value={food}
        onChangeText={(text) => setFood(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="칼로리"
        keyboardType="numeric"
        value={calories.toString()}
        onChangeText={(text) => setCalories(parseInt(text))}
      />
      <Button title="식사 추가" onPress={handleAddMeal} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8, // paddingHor -> paddingHorizontal로 수정
  },
});

export default AddMeal