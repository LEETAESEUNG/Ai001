import { useState } from 'react';
import { View, Text, Button, StyleSheet, TextInput } from 'react-native';

const EditMeal = ({ navigation, route }) => {
  const { meal } = route.params;
  const [food, setFood] = useState(meal.food);
  const [calories, setCalories] = useState(meal.calories);

  const handleEditMeal = () => {
    if (food && calories > 0) {
      const updatedMeal = { food, calories };
      const { editMeal } = route.params;
      editMeal(updatedMeal);
      navigation.goBack();
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>식사 편집</Text>
      <TextInput
        style={styles.input}
        placeholder="음식 이름"
        value={food}
        onChangeText={(text) => setFood(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="칼로리"
        keyboardType="numeric"
        value={calories.toString()}
        onChangeText={(text) => setCalories(parseInt(text))}
      />
      <Button title="변경 사항 저장" onPress={handleEditMeal} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
});

export default EditMeal;